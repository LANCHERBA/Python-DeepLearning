$.get("header.html",(data)=>{
    $("#header").html(data);
})