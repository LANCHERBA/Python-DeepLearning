# 学生考试表现数据集说明

## 变量说明

### 学生考试表现数据 StudentsPerformance.csv

1. gender	性别
2. race/ethnicity	种族
3. parental level of education	父母受教育水平
4. lunch	午餐
5. test preparation course	是否完成预科课程
6. math score	数学得分
7. reading score	阅读得分
8. writing score		写作得分

