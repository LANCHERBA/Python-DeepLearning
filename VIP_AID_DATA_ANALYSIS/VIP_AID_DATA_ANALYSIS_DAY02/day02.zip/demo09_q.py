import numpy as np
import matplotlib.pyplot as mp

def loadtxt():   
    """
    加载CustomerSurvival.csv
    """
    header = []
    data = []
    with open('CustomerSurvival.csv', 'r') as f:
        for index, line in enumerate(f.readlines()):
            if index == 0:
                header = line[:-1].split(',')
            else:
                data.append(tuple(line[:-1].split(',')))
        result = np.array(data, dtype={'names':header, 'formats':['f8', 'f8', 'f8', 'f8', 'f8', 'f8']})
    return result

data = loadtxt()
print(data.shape, data[0])

# 统计额外剩余时长，额外剩余流量，使用月份三个字段的 最小值，最大值，平均值，做出业务分析。
print('-' * 100)
extra_time_col = data['extra_time']
print('[extra_time] min:', min(extra_time_col), ' max:', max(extra_time_col), 'mean:', sum(extra_time_col) / len(extra_time_col))
extra_flow_col = data['extra_flow']
print('[extra_flow] min:', min(extra_flow_col), ' max:', max(extra_flow_col), 'mean:', sum(extra_flow_col) / len(extra_flow_col))
use_month_col = data['use_month']
print('[use_month] min:', min(use_month_col), ' max:', max(use_month_col), 'mean:', sum(use_month_col) / len(use_month_col))


# 统计所有有额外剩余通话时长的人数占总人数的比例。 统计所有有额外剩余流量的人数占总人数的比例。
print('-' * 100)
print(data[data['extra_time'] > 0].size / data.size)
print(data[data['extra_flow'] > 0].size / data.size)

# 统计每一类套餐的人数与总人数的占比并输出。
print('-' * 100)
types = set(data['pack_type'])
for t in types:
    print(t, ':', len(data[data['pack_type']==t]) / len(data))

# 整理剩余流量与用户流失之间的关系
extra_flow_col = data['extra_flow']
loss_col = data['loss']
print('loss==0  size:', len(data[loss_col==0]))
print('loss==1  size:', len(data[loss_col==1]))
mp.figure('extra_flow & loss', facecolor='lightgray')
mp.title('extra_flow & loss', fontsize=16)
mp.xlabel('extra_flow', fontsize=14)
mp.ylabel('loss', fontsize=14)
mp.grid(linestyle=':')
mp.scatter(extra_flow_col, loss_col, c=loss_col, cmap='jet', label='Samples')
mp.legend()

# 整理剩余通话时长与用户流失之间的关系
extra_time_col = data['extra_time']
loss_col = data['loss']
mp.figure('extra_time & loss', facecolor='lightgray')
mp.title('extra_time & loss', fontsize=16)
mp.xlabel('extra_time', fontsize=14)
mp.ylabel('loss', fontsize=14)
mp.grid(linestyle=':')
mp.scatter(extra_time_col, loss_col, c=loss_col, cmap='jet', label='Samples')
mp.legend()


# 研究非流失用户剩余流量与剩余通话时长之间的关系
x = extra_flow_col[loss_col==1]
y = extra_time_col[loss_col==1]
mp.figure('extra_flow & extra_time', facecolor='lightgray')
mp.title('extra_flow & extra_time', fontsize=16)
mp.xlabel('extra_flow', fontsize=14)
mp.ylabel('extra_time', fontsize=14)
mp.grid(linestyle=':')
mp.scatter(x, y, color='dodgerblue', alpha=0.7, label='Samples')
mp.legend()


mp.show()

