"""
demo03_fig.py 测试窗口操作
"""
import matplotlib.pyplot as mp

mp.figure('Figure A', facecolor='gray')
mp.plot([0, 1], [0, 1])
mp.figure('Figure B', facecolor='lightgray')
mp.plot([0, 1], [1, 0])
# 设置窗口的常用属性参数
mp.title('Test Title', fontsize=16)
mp.xlabel('Date', fontsize=14)
mp.ylabel('Price', fontsize=14)
mp.grid(linestyle=':')
mp.tight_layout()

# 重新绘制A窗口
mp.figure('Figure A')
mp.plot([1,2,3], [2,1,3])

mp.show()