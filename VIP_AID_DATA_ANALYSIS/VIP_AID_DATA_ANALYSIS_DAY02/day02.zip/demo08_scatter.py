"""
demo08_scatter.py  散点图
"""
import numpy as np
import matplotlib.pyplot as mp

n = 200
x = np.random.normal(175, 5, n)
y = np.random.normal(65, 10, n)

mp.figure('Scatter', facecolor='lightgray')
mp.title('Scatter', fontsize=16)
mp.grid(linestyle=':')
mp.scatter(x, y, marker='o', alpha=0.7, label='Samples', s=80, c=x, cmap='jet')
mp.legend()
mp.show()

