"""
demo02_plot.py  
"""
import numpy as np
import matplotlib.pyplot as mp

# 从-π到π 取1000个点
x = np.linspace(-np.pi, np.pi, 1000)
sinx = np.sin(x)
cosx = np.cos(x) / 2

# 修改x轴刻度文本
names = [r'$-\pi$', r'$-\frac{\pi}{2}$', '0', r'$\frac{\pi}{2}$', r'$\pi$']
mp.xticks([-np.pi, -np.pi/2, 0, np.pi/2, np.pi], names)

# 设置坐标轴
ax = mp.gca()
ax.spines['top'].set_color('none')
ax.spines['right'].set_color('none')
ax.spines['left'].set_position(('data', 0))
ax.spines['bottom'].set_position(('data', 0))

# 绘制曲线
mp.plot(x, sinx, linestyle='--', linewidth=2, alpha=0.7, color='dodgerblue', label=r'$y=sin(x)$')    
mp.plot(x, cosx, linestyle='-.', linewidth=2, alpha=0.7, color='orangered', label=r'$y=\frac{1}{2}cos(x)$')
# 绘制特殊点
xs, ys = [np.pi/2, np.pi/2], [1, 0]
mp.scatter(xs, ys, marker='D', edgecolors='red', facecolor='green', s=100, label='Points', zorder=3)

# 设置备注文本
mp.annotate(r'$[\frac{\pi}{2}, 1]$', xycoords='data', xy=(np.pi/2, 1), 
            textcoords='offset points', xytext=(30, 20), fontsize=14,
            arrowprops=dict(arrowstyle='->', connectionstyle='angle3'))

mp.legend()
mp.show()

