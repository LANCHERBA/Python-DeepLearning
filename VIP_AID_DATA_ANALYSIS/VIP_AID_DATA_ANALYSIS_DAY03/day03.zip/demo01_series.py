""""
demo01_series.py 
"""
import numpy as np
import pandas as pd

s = pd.Series()
print(s)

# 通过ndarray创建Series对象
ary = np.array(['张三', '李四', '王五', '赵柳'])
s = pd.Series(ary)
print(s)

s = pd.Series(ary, index=['S01', 'S02', 'S03', 'S04'])
print(s)

# 通过字典创建Series对象
data = {'S01': '张三', 'S02': '李思', 'S03': '王武', 'S04': '赵柳'}
s = pd.Series(data)
print(s)

# 通过标量创建Series对象
s = pd.Series(5, index=np.arange(200))
print(s)

# Series对象的数据访问
print("--" * 50)
data = {'S01': '张三', 'S02': '李思', 'S03': '王武', 'S04': '赵柳'}
s = pd.Series(data)
# 数组索引访问Series
print(s)
print(s[1])
print(s[:3])
print(s[-3:])
mask = [0,  2, 3]
print(s[mask])
# 通过标签索引访问Series
print(s['S02'])
print(s[:'S03'])
print(s['S03':])
mask = ['S01', 'S04']
print(s[mask])

# Series对象的常用属性
print(s.values)
print(s.index)

# 测试日期类型
dates = pd.Series(['2011', '2011-02', '2011-03-01', '2011-04-01 11:11:11', '2011/5/1', '01 Jun 2011'])
dates = pd.to_datetime(dates)
print(dates)

print(dates.dt.month)

print('-' * 50)
print(dates)
print(dates.dt.weekday)
print(dates.dt.quarter)

# 测试日期计算
print('-' * 50)
delta = dates - pd.to_datetime('1970-1-1')
print(delta)
print(delta.dt.days)

# 生成一组时间序列
dates = pd.date_range('2019-10-01', periods=7)
print(dates)

dates = pd.date_range('2019-10-01', periods=7, freq='M')
print(dates)

dates = pd.date_range('2019-10-01', periods=7, freq='B')
print(dates)

start = '2020-01-01'
end = '2020-02-01'
dates = pd.date_range(start, end)
print(dates)

