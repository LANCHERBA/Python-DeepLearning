import numpy as np
import pandas as pd

data = [1, 2, 3, 4, 5]
df = pd.DataFrame(data)
print(df, df.shape)

data = [['Alex', 12], ['Bob', 13], ['Clark', 14]]
df = pd.DataFrame(data, columns=['Name', 'Age'], dtype='float')
print(df)

data = [{'a':1, 'b':2}, {'a':3, 'b':5, 'c':7}]
df = pd.DataFrame(data)
print(df)

data = {'Name':['Alex', 'Bob', 'Clark'], 'Age':[12, 13, 14]}
df = pd.DataFrame(data, index=['S01', 'S02', 'S03'])
print(df)

data = {'one': pd.Series([1, 2, 3], index=['a', 'c', 'd']), 
        'two': pd.Series([1, 2, 3, 4], index=['e', 'f', 'g', 'h'])}
df = pd.DataFrame(data)
print(df)


print('--' * 50)
print(df.index)
print(df.columns)
print(df.values)
print(df.head(2))
print(df.tail(2))

# dataFrame的操作   列访问
print('--' * 50)
d = {'one' : pd.Series([1, 2, 3], index=['a', 'b', 'c']),
     'two' : pd.Series([1, 2, 3, 4], index=['a', 'b', 'c', 'd']), 
     'three' : pd.Series([1, 3, 4], index=['a', 'c', 'd'])}
df = pd.DataFrame(d)
print(df)
print(df['one'])
print(df[['one', 'three']])
print(df[df.columns[:2]])

# dataFrame的操作   列添加
print('--' * 50)
print(df)
df['four'] = pd.Series([1, 2, 3], index=['b', 'c', 'd'])
print(df)

# dataFrame的操作   列删除
print('--' * 50)
print(df)
df2 = df.drop(['one', 'two'], axis=1)
print(df2)

# dataFrame的操作   行访问
print('--' * 50)
print(df)
print(df[1:3])
print(df['b':'d'])
print(df[1:2])
print(df.loc[['a', 'c']])
print(df.iloc[[0, 2]])

# dataFrame的操作   行删除
print('--' * 50)
print(df)
print(df.drop('d'))
print(df.drop(['a', 'b']))

# 复合索引的使用
print('--' * 50)
data = np.floor(np.random.normal(85, 3, (6,3)))
df = pd.DataFrame(data)
print(df)
index = [('classA', 'F'), ('classA', 'M'), ('classB', 'F'), ('classB', 'M'), ('classC', 'F'), ('classC', 'M')]
df.index = pd.MultiIndex.from_tuples(index)
print(df)
columns = [('Age', '20+'), ('Age', '30+'), ('Age', '40+')]
df.columns = pd.MultiIndex.from_tuples(columns)
print(df)

# 通过复合索引检索数据
print('--' * 50)
print(df)
print(df.loc['classA'])
print(df.loc[['classA', 'classC']])
print(df.loc['classA', 'M'])
print(df.loc['classA', 'M']['Age', '40+'])

print(df.Age)
print(df.Age['20+'])
print(df['Age']['20+'])
print(df['Age', '20+'])





