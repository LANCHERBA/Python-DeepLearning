# 10_variable.py
# 变量使用示例
"""
1. 变量是一种特殊的张量，变量中存的值是张量
2. 变量可以进行持久化保存，张量则不可
3. 变量使用之前，要进行显式初始化
"""
import tensorflow as tf

a = tf.constant([1, 2, 3, 4])
var = tf.Variable(tf.random_normal([2, 3], mean=0.0, stddev=1.0), #初始值
                  name="var")
# 变量操作执行之前，需要进行全局初始化(初始化也是一个op,需要在session的run方法中执行)
init_op = tf.global_variables_initializer()

with tf.Session() as sess:
    sess.run(init_op)
    print(sess.run([a, var]))