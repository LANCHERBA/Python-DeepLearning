# 12_lr.py
# 线性回归示例
import tensorflow as tf

# 第一步：创建样本数据
x = tf.random_normal([100, 1], mean=1.75, stddev=0.5, name="x_data")
y_true = tf.matmul(x, [[2.0]]) + 5.0  # 计算 y = 2x + 5

# 第二步：建立线性模型
## 初始化权重(随机数)和偏置（固定设置为0）,计算wx+b得到预测值
weight = tf.Variable(tf.random_normal([1, 1], name="w"),
                     trainable=True)  # 训练过程中值是否允许变化
bias = tf.Variable(0.0, name="b", trainable=True)  # 偏置
y_predict = tf.matmul(x, weight) + bias  # 计算预测值

# 第三步：创建损失函数
loss = tf.reduce_mean(tf.square(y_true - y_predict))  # 均方差损失函数

# 第四步：使用梯度下降进行训练
train_op = tf.train.GradientDescentOptimizer(0.1).minimize(loss)

# 收集损失函数的值
tf.summary.scalar("losses", loss)
merged = tf.summary.merge_all()  # 合并摘要操作

init_op = tf.global_variables_initializer()
with tf.Session() as sess:
    sess.run(init_op)  # 执行初始化op

    # 打印初始权重和偏置
    print("weight:", weight.eval(), " bias:", bias.eval())

    # 指定事件文件并记录图的信息
    fw = tf.summary.FileWriter("../summary/", graph=sess.graph)

    # 循环训练
    for i in range(500):
        sess.run(train_op)  # 执行训练
        summary = sess.run(merged)  # 执行摘要合并操作
        fw.add_summary(summary, i)  # 写入事件文件

        print(i, ":", " weight:", weight.eval(), " bias:", bias.eval())
