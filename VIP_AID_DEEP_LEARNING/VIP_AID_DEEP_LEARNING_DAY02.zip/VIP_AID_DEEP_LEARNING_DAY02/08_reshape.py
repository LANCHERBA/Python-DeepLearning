# 08_reshape.py
# 张量形状改变
# 静态形状：初始形状，只能设置一次，不能跨阶设置
# 动态形状：运行时的形状，可以多次设置，可以跨阶设置，但元素总数要一致
import tensorflow as tf

pld = tf.placeholder(tf.float32, [None, 3])

pld.set_shape([4, 3]) # 设置静态形状，一旦固定就不能再改变
print(pld)
# pld.set_shape([3, 3]) # 报错

# 设置张量的动态形状，实际是创建一个新的张量
new_pld = tf.reshape(pld, [3, 4]) # 设置动态形状
print(new_pld)

new_pld = tf.reshape(pld, [2, 6]) # 多次设置动态形状
print(new_pld)

# new_pld = tf.reshape(pld, [2, 4]) # 报错，元素个数不匹配

with tf.Session() as sess:
    pass