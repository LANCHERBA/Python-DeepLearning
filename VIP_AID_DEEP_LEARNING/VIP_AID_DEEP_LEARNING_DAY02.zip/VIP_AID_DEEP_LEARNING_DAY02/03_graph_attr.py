# 03_graph_attr.py
# 查看默认图的属性
import tensorflow as tf

a = tf.constant(5.0)
print(a)
b = tf.constant(1.0)
c = tf.add(a, b)

graph = tf.get_default_graph() # 获取默认的图
print("graph:",graph)

# 新创建一个图
graph2 = tf.Graph()
print("graph2:",graph2)
with graph2.as_default(): # 设置为默认图
    d = tf.constant(11.0) # 操作d属于graph2

with tf.Session(graph=graph2) as sess: # 指定执行graph2
    # print(sess.run(c)) # 报错，因为c没有在默认graph2中
    print(sess.run(d))
    print(a.graph) # 打印张量的graph属性
    print(c.graph) # 打印c操作的graph属性
    print(sess.graph) # 打印session的graph属性

