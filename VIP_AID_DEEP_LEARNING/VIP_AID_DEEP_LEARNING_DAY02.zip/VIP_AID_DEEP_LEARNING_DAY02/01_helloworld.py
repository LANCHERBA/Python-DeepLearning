# 01_helloworld.py
# tensorflow版本的helloworld
import tensorflow as tf

hello = tf.constant("hello, world!") # 定义一个常量(张量)
sess = tf.Session() # 创建一个session, 用来执行操作
print(sess.run(hello)) # 调用session的run方法，执行hello操作，并打印结果
sess.close() # 关闭session