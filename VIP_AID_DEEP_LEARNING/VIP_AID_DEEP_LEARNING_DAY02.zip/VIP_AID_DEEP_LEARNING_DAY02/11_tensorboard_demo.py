# 11_tensorboard_demo.py
# 将图中的信息存入事件文件，并在tensorboard中显示示例
import tensorflow as tf

# 创建一组操作
a = tf.constant([1, 2, 3, 4, 5]) # 普通张量
var = tf.Variable(tf.random_normal([2,3], mean=0.0, stddev=1.0),
                  name="var") #变量

b = tf.constant(3.0, name="a") #这里故意将python变量和tf的op名称取的不一致
c = tf.constant(4.0, name="b")
d = tf.add(b, c, name="add")

# 显式初始化
init_op = tf.global_variables_initializer()

with tf.Session() as sess:
    sess.run(init_op)
    #将当前session的graph信息写入事件文件
    fw = tf.summary.FileWriter("../summary/", graph=sess.graph)
    print(sess.run([a, var, d]))
