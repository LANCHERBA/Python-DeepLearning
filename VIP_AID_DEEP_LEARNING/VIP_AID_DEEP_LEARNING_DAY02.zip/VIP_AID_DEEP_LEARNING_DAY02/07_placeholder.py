# 07_placeholder.py
# 占位符使用示例：占位符在使用时，必须传入参数

import tensorflow as tf

# 定义两个占位符
plhd = tf.placeholder(tf.float32, [2, 3]) # 定义2行3列的占位符
plhd2 = tf.placeholder(tf.float32, [None, 3]) # N行3列占位符
plhd3 = tf.placeholder(tf.float32, [None, 4])

with tf.Session() as sess:
    d = [[1, 2, 3],
         [4, 5, 6]]
    print(sess.run(plhd, feed_dict={plhd:d})) # 执行占位符操作，需要传入数据
    print(sess.run(plhd2, feed_dict={plhd2:d})) # 定义为N行3列，执行时传入2行3列
    # print(sess.run(plhd3, feed_dict={plhd3:d})) # 定义为N行4列，执行时传入2行3列