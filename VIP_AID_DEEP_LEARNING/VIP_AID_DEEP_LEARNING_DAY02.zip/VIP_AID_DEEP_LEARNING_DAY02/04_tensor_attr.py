# 04_tensor_attr.py
# 查看张量属性示例
import tensorflow as tf

a = tf.constant(5.0)  # 标量

with tf.Session() as sess:
    print(sess.run(a))
    print("name:", a.name)  # name属性
    print("dtype:", a.dtype)  # dtype
    print("shape:", a.shape)  # shape
    print("op:", a.op)  # op
    print("graph:", a.graph)  # graph
