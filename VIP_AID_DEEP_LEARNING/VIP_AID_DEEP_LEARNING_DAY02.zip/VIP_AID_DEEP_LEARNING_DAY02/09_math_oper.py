# 09_math_oper.py
# 张量的数学计算示例
import tensorflow as tf

x = tf.constant([[1, 2],
                 [3, 4]], dtype=tf.float32)
y = tf.constant([[4, 3],
                 [3, 2]], dtype=tf.float32)

x_add_y = tf.add(x, y)  # 张量相加
x_mul_y = tf.matmul(x, y) # 张量相乘(按照矩阵相乘的规则)
log_x = tf.log(x) # 求对数
x_sum_1 = tf.reduce_sum(x, axis=[0]) # 1-行方向 0-列方向

# 张量计算片段和
data = tf.constant([1,2,3,4,5,6,7,8,9,10], dtype=tf.float32)
segment_ids = tf.constant([0, 0, 0, 1, 1, 2, 2, 2, 2, 2], dtype=tf.int32)
x_seg_sum = tf.segment_sum(data, segment_ids)

with tf.Session() as sess:
    print(x_add_y.eval())
    print(x_mul_y.eval())
    print(log_x.eval())
    print(x_sum_1.eval())
    print(x_seg_sum.eval())
