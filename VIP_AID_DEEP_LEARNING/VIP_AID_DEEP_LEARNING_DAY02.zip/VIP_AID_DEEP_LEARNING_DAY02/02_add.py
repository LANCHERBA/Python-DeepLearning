# 02_add.py
# 张量相加的示例
import tensorflow as tf

a = tf.constant(5.0) # 张量a
b = tf.constant(1.0) # 张量b
c = tf.add(a, b) # 张量相加

with tf.Session() as sess:
    print(sess.run(c))
