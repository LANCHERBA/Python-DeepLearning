# 02_img_conv.py
# 图像卷积示例
from scipy import signal
from scipy import misc
import matplotlib.pyplot as plt
import numpy as np
import scipy.ndimage as sn

im = misc.imread("d:\\tmp\\lily.png", flatten=True)  # linux： /home/tarena/lily.png
# im = sn.imread("d:\\tmp\\lily.png", flatten=True)

flt = np.array([[-1, 0, 1],
                [-2, 0, 2],
                [-1, 0, 1]])  # 卷积核(过滤器)
flt2 = np.array([[1, 2, 1],
                 [0, 0, 0],
                 [-1, -2, -1]]) # 另一个卷积核(对垂直方向上的色彩变化敏感)
grad = signal.convolve2d(im,  # 输入数据
                         flt,  # 卷积核
                         boundary="symm",  # 边沿处理方式
                         mode="same").astype("int32")  # same表示同维卷积
grad2 = signal.convolve2d(im,  # 输入数据
                        flt2,  # 卷积核
                         boundary="symm",  # 边沿处理方式
                         mode="same").astype("int32")  # same表示同维卷积
# 可视化
plt.figure("Conv2D")
plt.subplot(131)  # 第一个子图, 显示原图
plt.imshow(im, cmap="gray")  # 显示原图
plt.xticks([])
plt.yticks([])

plt.subplot(132)  # 第二个子图, 显示卷积后的图像
plt.imshow(grad, cmap="gray")  # 显示卷积后的图像
plt.xticks([])
plt.yticks([])

plt.subplot(133)  # 第三个子图, 显示flt2卷积后的图像
plt.imshow(grad2, cmap="gray")  # 显示flt2卷积后的图像
plt.xticks([])
plt.yticks([])
plt.show()
