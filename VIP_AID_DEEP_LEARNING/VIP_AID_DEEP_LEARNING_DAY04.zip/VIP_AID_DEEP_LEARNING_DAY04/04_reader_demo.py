# 04_reader_demo.py
import paddle


# 原始读取器
def reader_creator(file_path):
    def reader():
        with open(file_path, "r") as f:  # 打开文件
            lines = f.readlines()  # 读取所有行
            for line in lines:
                yield line.replace("\n", "")  # 利用生成器关键字创建一个数据并返回

    return reader


reader = reader_creator("test.txt")  # 原始顺序读取器
shuffle_reader = paddle.reader.shuffle(reader, 10)  # 随机读取器
batch_reader = paddle.batch(shuffle_reader, 3)  # 批量随机读取器

# for data in reader():  # 迭代
# for data in shuffle_reader(): # 对随机读取器进行迭代
for data in batch_reader():  # 对批量随机读取器进行迭代
    print(data, end="")
