# 01_csv_reader.py
# CSV文件读取示例
import tensorflow as tf
import os


def csv_read(filelist):  # 从csv样本文件中读取数据
    # 构建文件队列
    file_queue = tf.train.string_input_producer(filelist)
    # 定义reader
    reader = tf.TextLineReader()
    k, v = reader.read(file_queue)  # 读取，返回文件名称、数据
    # 解码
    records = [["None"], ["None"]]
    example, label = tf.decode_csv(v, record_defaults=records)
    # 批处理
    example_bat, label_bat = tf.train.batch([example, label],  # 参与批处理的数据
                                            batch_size=4,  # 批次大小
                                            num_threads=1)  # 线程数量
    return example_bat, label_bat


if __name__ == "__main__":
    # 构建文件列表
    dir_name = "../test_data/"
    file_names = os.listdir(dir_name)  # 列出目录下所有的文件
    file_list = []
    for f in file_names:
        # 将目录名称、文件名称拼接称完整路径，并添加到文件列表
        file_list.append(os.path.join(dir_name, f))

    example, label = csv_read(file_list)  # 调用自定义函数，读取指定文件列表中的数据

    # 开启Session,执行
    with tf.Session() as sess:
        coord = tf.train.Coordinator()  # 定义线程协调器
        threads = tf.train.start_queue_runners(sess, coord=coord)
        print(sess.run([example, label]))  # 执行操作

        # 等待线程停止，并回收资源
        coord.request_stop()
        coord.join(threads)
