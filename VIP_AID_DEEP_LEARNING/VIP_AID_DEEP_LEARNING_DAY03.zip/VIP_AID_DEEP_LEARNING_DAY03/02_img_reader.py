# 02_img_reader.py
# 图像样本读取示例
import tensorflow as tf
import os

# 图像样本读取函数
def img_read(filelist):
    # 构建文件队列
    file_queue = tf.train.string_input_producer(filelist)
    # 定义reader
    reader = tf.WholeFileReader()
    k, v = reader.read(file_queue) # 读取整个文件内容
    # 解码
    img = tf.image.decode_jpeg(v)
    # 批处理
    img_resized = tf.image.resize(img, [200, 200]) # 将图像设置成200*200大小
    img_resized.set_shape([200, 200, 3]) # 固定样本形状，批处理时对数据形状有要求
    img_bat = tf.train.batch([img_resized],
                             batch_size=10,
                             num_threads=1)
    return img_bat

if __name__ == "__main__":
    # 构建文件列表
    dir_name = "../test_img/"
    file_names = os.listdir(dir_name)
    file_list = []
    for f in file_names:
        # 将目录名、文件名拼接成完整路径放入文件列表中
        file_list.append(os.path.join(dir_name, f))

    imgs = img_read(file_list)

    with tf.Session() as sess:
        coord = tf.train.Coordinator() # 线程协调器
        threads = tf.train.start_queue_runners(sess, coord=coord)
        result = imgs.eval() # 调用函数，分批次读取样本

        # 等待线程结束，并回收资源
        coord.request_stop()
        coord.join(threads)

# 显示图片
import matplotlib.pyplot as plt

plt.figure("Img Show", facecolor="lightgray")

for i in range(10):  # 循环显示读取到的样本(批次读取，所以有多个样本)
    plt.subplot(2, 5, i+1) # 显示子图, 2行5列的第i+1个子图
    plt.xticks([])
    plt.yticks([])
    plt.imshow(result[i].astype("int32"))

plt.tight_layout()
plt.show()