# 10_resize.py
# 图像缩放示例
import cv2

im = cv2.imread("../data/Linus.png")
cv2.imshow("im", im)

h, w = im.shape[:2] # 获取图像高度、宽度

# 缩小
dst_size = (int(w/2), int(h/2)) # 计算缩放后的图像宽度、高度
resized = cv2.resize(im, dst_size)
cv2.imshow("reduce", resized)

# 放大
dst_size = (200, 300) # 缩放尺寸，宽200，高300
resized = cv2.resize(im,
                     dst_size,
                     interpolation=cv2.INTER_NEAREST) # 最邻近插值
cv2.imshow("NEAREST", resized)


resized = cv2.resize(im,
                     dst_size,
                     interpolation=cv2.INTER_LINEAR) # 双线性插值
cv2.imshow("LINEAR", resized)


cv2.waitKey() # 等待用户按某个按键
cv2.destroyAllWindows() # 销毁所有创建的窗口