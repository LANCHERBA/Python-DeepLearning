# 19_morho_gradient.py
# 形态学梯度：膨胀的图像减腐蚀的图像
import cv2
import numpy as np

o = cv2.imread("../data/6.png")

k = np.ones((3, 3), np.uint8)  # 计算核
r = cv2.morphologyEx(o, cv2.MORPH_GRADIENT, k)  # 计算形态学梯度

cv2.imshow("o", o)
cv2.imshow("r", r)

cv2.waitKey()
cv2.destroyAllWindows()
