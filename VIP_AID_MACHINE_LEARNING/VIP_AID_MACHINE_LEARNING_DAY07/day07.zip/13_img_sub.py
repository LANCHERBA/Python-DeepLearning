# 13_img_sub.py
# 图像相减
import cv2

a = cv2.imread("../data/3.png", 0)
b = cv2.imread("../data/4.png", 0)

dst = cv2.subtract(a, b) # 图像相减

cv2.imshow("a", a)
cv2.imshow("b", b)
cv2.imshow("dst", dst)

cv2.waitKey()  # 等待用户按某个按键
cv2.destroyAllWindows()  # 销毁所有创建的窗口