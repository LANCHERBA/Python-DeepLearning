# 14_perspective.py
# 透视变换
import cv2
import numpy as np

im = cv2.imread("../data/pers.png")
rows, cols = im.shape[:2]  # 取出高度、宽度
print(rows, cols)
cv2.imshow("im", im)

# 指定映射坐标
pts1 = np.float32([[58, 2], [167, 9], [8, 196], [126, 196]])  # 原坐标点
pts2 = np.float32([[16, 2], [167, 8], [8, 196], [169, 196]])  # 目标点坐标

# 生成透视变换矩阵
M = cv2.getPerspectiveTransform(pts1, pts2)

# 执行变换
dst = cv2.warpPerspective(im,  # 原始图像
                          M,  # 变换矩阵
                          (cols, rows))  # 输出图像大小
cv2.imshow("dst", dst)

# 将矩形变换成平行四边形
M = cv2.getPerspectiveTransform(pts2, pts1)
dst2 = cv2.warpPerspective(im,  # 原始图像
                           M,  # 变换矩阵
                           (cols, rows))  # 输出图像大小
cv2.imshow("dst2", dst2)

cv2.waitKey()  # 等待用户按某个按键
cv2.destroyAllWindows()  # 销毁所有创建的窗口
