# 17_img_open.py
# 图像开运算
import cv2
import numpy as np

im1 = cv2.imread("../data/7.png")
im2 = cv2.imread("../data/8.png")

# 执行开运算
k = np.ones((10, 10), np.uint8)  # 计算核
r1 = cv2.morphologyEx(im1, cv2.MORPH_OPEN, k)
r2 = cv2.morphologyEx(im2, cv2.MORPH_OPEN, k)

cv2.imshow("im1", im1)
cv2.imshow("im2", im2)
cv2.imshow("r1", r1)
cv2.imshow("r2", r2)

cv2.waitKey()  # 等待用户按某个按键
cv2.destroyAllWindows()  # 销毁所有创建的窗口
