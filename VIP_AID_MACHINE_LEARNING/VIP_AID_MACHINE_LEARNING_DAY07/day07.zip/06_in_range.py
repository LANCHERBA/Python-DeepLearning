# 06_in_range.py
# 通过inRange函数提取指定的颜色
import cv2
import numpy as np

im = cv2.imread("../data/opencv2.png")
cv2.imshow("im", im)

# BGR ==> HSV
hsv = cv2.cvtColor(im, cv2.COLOR_BGR2HSV)

# 提取蓝色部分
# 蓝色部分色彩范围：H为120，取上下10的范围
# S通道和V通道取50~255, 饱和度太低、亮度太低的部分颜色判断不准确，所以不取
minBlue = np.array([110, 50, 50])
maxBlue = np.array([130, 255, 255])
# 提取出上述范围
mask = cv2.inRange(hsv, minBlue, maxBlue)
cv2.imshow("mask", mask)
# 利用mask和原图做按位和运算，提取出了mask中的部分
blue = cv2.bitwise_and(im, im, mask=mask)
cv2.imshow("blue", blue)

# =============指定绿色值的范围=============
minGreen = np.array([50, 50, 50])
maxGreen = np.array([70, 255, 255])
# 确定绿色区域
mask = cv2.inRange(hsv, minGreen, maxGreen)
# cv2.imshow("mask", mask)
# 通过掩码控制的按位与运算，锁定绿色区域
green = cv2.bitwise_and(im, im, mask=mask)  # 执行掩模运算
cv2.imshow('green', green)

# =============指定红色值的范围=============
minRed = np.array([0, 50, 50])
maxRed = np.array([30, 255, 255])
# 确定红色区域
mask = cv2.inRange(hsv, minRed, maxRed)
# cv2.imshow("mask", mask)
# 通过掩码控制的按位与运算，锁定红色区域
red = cv2.bitwise_and(im, im, mask=mask)  # 执行掩模运算
cv2.imshow('red', red)

cv2.waitKey() # 等待用户按某个按键
cv2.destroyAllWindows() # 销毁所有创建的窗口
