# 12_img_add.py
# 图像相加
import cv2

a = cv2.imread("../data/lena.jpg", 0)
b = cv2.imread("../data/lily_square.png", 0)

# 图像直接相加，会导致图像越加越白，越加越亮
dst1 = cv2.add(a, b)
cv2.imshow("dst1", dst1)

# 图像按权重相加
dst2 = cv2.addWeighted(a, 0.2,  # 图像1和权重
                       b, 0.8,  # 图像2和权重
                       0)  # 亮度调节量
cv2.imshow("dst2", dst2)

cv2.waitKey()  # 等待用户按某个按键
cv2.destroyAllWindows()  # 销毁所有创建的窗口
