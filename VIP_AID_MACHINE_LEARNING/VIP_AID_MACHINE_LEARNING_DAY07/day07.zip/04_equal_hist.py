# 04_equal_hist.py
# 直方图均衡化处理：equalizeHist
import cv2
import numpy as np
from matplotlib import pyplot as plt

im = cv2.imread("../data/sunrise.jpg", 0) # 读取灰度图像
cv2.imshow("im", im)

# 直方图均衡化处理
im_equ = cv2.equalizeHist(im)
cv2.imshow("im_equ", im_equ)

# 绘制灰度直方图
## 原始图像直方图绘制
plt.subplot(2, 1, 1)
plt.hist(im.ravel(), # 返回一个扁平的数组
         256, [0, 256], label="orig")
plt.legend()

## 均衡化处理后的图像直方图绘制
plt.subplot(2, 1, 2)
plt.hist(im_equ.ravel(), 256, [0, 256], label="equlized")
plt.legend()

plt.show()

cv2.waitKey() # 等待用户按某个按键
cv2.destroyAllWindows() # 销毁所有创建的窗口