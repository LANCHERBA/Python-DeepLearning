# 16_dilate.py
# 图像膨胀
import cv2
import numpy as np

im = cv2.imread("../data/6.png")
cv2.imshow("im", im)

# 膨胀
kernel = np.ones((3, 3), np.uint8) # 膨胀核
dilation = cv2.dilate(im, # 图像
                      kernel, # 膨胀核
                      iterations=7) # 迭代次数
cv2.imshow("dilation", dilation)

cv2.waitKey()  # 等待用户按某个按键
cv2.destroyAllWindows()  # 销毁所有创建的窗口