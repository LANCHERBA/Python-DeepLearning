# 07_img_binary.py
# 图像二值化/反二值化处理
import cv2

im = cv2.imread("../data/lena.jpg", 0) # 读取灰度图像
cv2.imshow("im", im)

# 二值化
t, rst = cv2.threshold(im,
                       80, # 阈值
                       255, # 最大值
                       cv2.THRESH_BINARY) # 二值化
cv2.imshow("bin", rst)

# 反二值化
t, rst2 = cv2.threshold(im,
                       80, # 阈值
                       255, # 最大值
                       cv2.THRESH_BINARY_INV) # 反二值化
cv2.imshow("bin_inv", rst2)

cv2.waitKey() # 等待用户按某个按键
cv2.destroyAllWindows() # 销毁所有创建的窗口
