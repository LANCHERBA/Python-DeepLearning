# 11_crop.py
# 图像裁剪(利用数组切片操作实现)
import numpy as np
import cv2


# 随机裁剪
def random_crop(im, w, h):
    # 随机产生裁剪起点的x, y坐标
    start_x = np.random.randint(0, im.shape[1])  # 裁剪起始x坐标
    start_y = np.random.randint(0, im.shape[0])  # 裁剪起始y坐标

    new_img = im[start_y:start_y + h, start_x:start_x + w]  # 切片

    return new_img


# 中心裁剪
def center_crop(im, w, h):
    start_x = int(im.shape[1] / 2) - int(w / 2)  # 裁剪起始x坐标
    start_y = int(im.shape[0] / 2) - int(h / 2)  # 裁剪起始y坐标

    new_img = im[start_y:start_y + h, start_x:start_x + w]  # 切片

    return new_img


if __name__ == '__main__':
    im = cv2.imread("../data/banana_1.png", 1)

    new_img = random_crop(im, 200, 200)  # 随机裁剪
    cv2.imshow("random_crop", new_img)

    new_img2 = center_crop(im, 200, 200)
    cv2.imshow("center_crop", new_img2)

    cv2.waitKey()  # 等待用户按某个按键
    cv2.destroyAllWindows()  # 销毁所有创建的窗口
