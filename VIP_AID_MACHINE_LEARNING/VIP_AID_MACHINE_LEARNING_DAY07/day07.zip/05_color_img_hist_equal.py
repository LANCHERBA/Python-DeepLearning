# 05_color_img_hist_equal.py
# 彩色图像直方图均衡化处理
import cv2

im = cv2.imread("../data/sunrise.jpg")
cv2.imshow("im", im)

# BGR ==> YUV
yuv = cv2.cvtColor(im, cv2.COLOR_BGR2YUV)

# 取出亮度通道，进行均衡化处理，并将均衡化处理后的值赋值回原图像
yuv[..., 0] = cv2.equalizeHist(yuv[..., 0])

# YUV ==> BGR
equlized_color = cv2.cvtColor(yuv, cv2.COLOR_YUV2BGR)
cv2.imshow("equlized_color", equlized_color)

cv2.waitKey() # 等待用户按某个按键
cv2.destroyAllWindows() # 销毁所有创建的窗口