# 绘制轮廓外接矩形框
import cv2
import numpy as np

im = cv2.imread("../data/cloud.png", 0)
cv2.imshow("im", im)

# 二值化处理
ret, im_binary = cv2.threshold(im, 127, 255, cv2.THRESH_BINARY)
img, cnts, hie = cv2.findContours(im_binary,
                                  cv2.RETR_LIST,  # 不建立等级关系
                                  cv2.CHAIN_APPROX_NONE)  # 存储轮廓所有坐标点
# print(cnts[0].shape)

# 根据轮廓产生外接矩形框参数
x, y, w, h = cv2.boundingRect(cnts[0])

# 绘制矩形框
brcnt = np.array([[[x, y]], [[x + w, y]], [[x + w, y + h]], [[x, y + h]]])
cv2.drawContours(im, [brcnt], -1, (255,255,255), 2)
cv2.imshow("result", im)

cv2.waitKey()
cv2.destroyAllWindows()
