# 读取视频文件并播放
import cv2

# 创建对象，并制定打开的视频文件路径
cap = cv2.VideoCapture("d:\\tmp\\test.mp4")
while cap.isOpened():
    ret, frame = cap.read() # 读取帧
    cv2.imshow("frame", frame) # 显示
    c = cv2.waitKey(25) # 等待用户敲击按键
    if c == 27:
        break
cap.release()
cv2.destroyAllWindows()