# 查找并绘制轮廓
import cv2
import numpy as np

im = cv2.imread("../data/3.png")
cv2.imshow("im", im)

#  灰度化
im_gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
# 二值化
ret, im_binary = cv2.threshold(im_gray, 127, 255, cv2.THRESH_BINARY)
# cv2.imshow("im_binary", im_binary)

# 查找轮廓
img, cnts, hie = cv2.findContours(im_binary,  # 原图(经过二值化处理后的)
                                  cv2.RETR_EXTERNAL,  # 只检测外轮廓
                                  cv2.CHAIN_APPROX_NONE)  # 存储所有轮廓点
# print(type(cnts))  # list
# for cnt in cnts:
#     print(cnt.shape)

# 绘制轮廓
im_cnt = cv2.drawContours(im,  # 原始图像
                          cnts,  # 轮廓数据, findContours的返回值
                          -1,  # 绘制所有轮廓
                          (0, 0, 255),  # 轮廓颜色：红色
                          2)  # 轮廓粗细
cv2.imshow("im_cnt", im_cnt)

cv2.waitKey()
cv2.destroyAllWindows()
