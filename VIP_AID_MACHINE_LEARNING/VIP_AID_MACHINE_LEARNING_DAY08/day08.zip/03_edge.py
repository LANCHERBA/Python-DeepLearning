# 边沿检测示例
import cv2

im = cv2.imread("../data/lily.png", 0)
cv2.imshow("im", im)

## sobel边沿提取
sobel = cv2.Sobel(im,  # 原始图像
                  cv2.CV_64F,  # 输出图像深度
                  1, 1,  # 水平、垂直方向滤波计算
                  ksize=5)  # 滤波器大小
cv2.imshow("sobel", sobel)

## Laplacian边沿提取
lap = cv2.Laplacian(im, cv2.CV_64F)
cv2.imshow("Laplacian", lap)

## Canny边沿提取
canny = cv2.Canny(im,
                  50,  # 滞后阈值
                  360)  # 模糊度
cv2.imshow("canny", canny)

cv2.waitKey()
cv2.destroyAllWindows()
