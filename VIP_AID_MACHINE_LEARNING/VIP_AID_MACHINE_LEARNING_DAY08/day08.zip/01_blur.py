# 图像模糊化处理
import cv2
import numpy as np

im = cv2.imread("../data/lena.jpg", 0)
cv2.imshow("im", im)

## 中值滤波
im_median_blur = cv2.medianBlur(im, 5)
cv2.imshow("im_median_blur", im_median_blur)

## 均值滤波
im_mean_blur = cv2.blur(im, (3, 3))
cv2.imshow("im_mean_blur", im_mean_blur)

## 高斯滤波
im_guassian_blur = cv2.GaussianBlur(im, (5, 5), 3)
cv2.imshow("im_guassian_blur", im_guassian_blur)

## 自定义高斯核执行滤波计算
gaussian_blur = np.array([
    [1, 4, 7, 4, 1],
    [4, 16, 26, 16, 4],
    [7, 26, 41, 26, 7],
    [4, 16, 26, 16, 4],
    [1, 4, 7, 4, 1]], np.float32) / 273
# 使用filter2D执行滤波计算
im_guassian_blur2 = cv2.filter2D(im,  # 原始图像
                                 -1,  # 目标图像深度，-1表示和原图像相同
                                 gaussian_blur)  # 滤波器
cv2.imshow("im_guassian_blur2", im_guassian_blur2)

cv2.waitKey()
cv2.destroyAllWindows()
