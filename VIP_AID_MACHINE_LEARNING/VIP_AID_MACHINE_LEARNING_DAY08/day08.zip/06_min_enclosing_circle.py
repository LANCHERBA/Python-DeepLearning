# 绘制轮廓最小圆形包围圈
import cv2
import numpy as np

im = cv2.imread("../data/cloud.png", 0)
cv2.imshow("im", im)

# 二值化处理
ret, im_binary = cv2.threshold(im, 127, 255, cv2.THRESH_BINARY)
img, cnts, hie = cv2.findContours(im_binary,
                                  cv2.RETR_LIST,
                                  cv2.CHAIN_APPROX_NONE)
(x, y), radius = cv2.minEnclosingCircle(cnts[0])  # 产生轮廓的最小外接圆形参数
# print((x,y), radius)
center = (int(x), int(y))  # 将圆心的坐标转换为整型
radius = int(radius)  # 将半径转换为整型

cv2.circle(im, center, radius, (255, 255, 255), 2)  # 绘制圆形
cv2.imshow("result", im)

cv2.waitKey()
cv2.destroyAllWindows()
