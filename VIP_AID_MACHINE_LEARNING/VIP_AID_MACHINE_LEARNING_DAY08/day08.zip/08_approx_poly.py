# 使用多边形对轮廓进行拟合
import cv2
import numpy as np

im = cv2.imread("../data/cloud.png")
cv2.imshow("im", im)

# 转灰度图像
im_gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
# 二值化
ret, im_binary = cv2.threshold(im_gray, 127, 255, cv2.THRESH_BINARY)
# 查找轮廓
img, cnts, hie = cv2.findContours(im_binary,
                                  cv2.RETR_LIST,
                                  cv2.CHAIN_APPROX_NONE)
# 精度一
adp = im.copy()
epsilon = 0.005 * cv2.arcLength(cnts[0], True)  # 精度，根据周长计算
approx = cv2.approxPolyDP(cnts[0], epsilon, True)  # 构造多边形，返回多边形数据
adp = cv2.drawContours(adp, [approx], 0, (0, 0, 255), 2)  # 绘制
cv2.imshow("result_0.005", adp)

# 精度二
adp2 = im.copy()
epsilon = 0.01 * cv2.arcLength(cnts[0], True)
approx = cv2.approxPolyDP(cnts[0], epsilon, True)
adp = cv2.drawContours(adp2, [approx], 0, (0, 0, 255), 2)
cv2.imshow("result_0.01", adp2)

cv2.waitKey()
cv2.destroyAllWindows()
